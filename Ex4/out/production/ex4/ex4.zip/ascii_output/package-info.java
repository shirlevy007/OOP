/**
 * The module responsible for outputting Ascii images.
 * @author Dan Nirel
 */
package ascii_output;