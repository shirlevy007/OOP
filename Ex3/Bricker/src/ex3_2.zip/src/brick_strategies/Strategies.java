package src.brick_strategies;

/**
 * all strategies to be used by Factory
 */
enum Strategies {BASIC,EXTRA_BALLS,EXTRA_PADDLE,CHANGE_CAMERA,EXTRA_LIFE,DOUBLE}
