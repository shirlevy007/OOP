package src.brick_strategies;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.util.Counter;

public class CollisionStrategy {
    /**
     *  An object which holds all game objects of the game running
     */
    private final GameObjectCollection gameObjectCollection;

    /**
     * The constructor of the Strategy object
     *
     * @param gameObjectCollection  An object which holds all game objects of the game running
     */
    public CollisionStrategy(GameObjectCollection gameObjectCollection) {

        this.gameObjectCollection = gameObjectCollection;
    }

    /**
     *
     * @param thisObj the object that was collided (the brick)
     * @param otherObj the object that collided with the brick (the ball).
     * @param bricksCounter bricks left in the game
     */
    public void onCollision(GameObject thisObj, GameObject otherObj, Counter bricksCounter) {
        gameObjectCollection.removeGameObject(thisObj, Layer.STATIC_OBJECTS);
        bricksCounter.decrement();

    }
}
