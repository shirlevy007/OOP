/**
 * marks on the board: players X,O and BLANK for non-taken spots
 */
enum Mark {BLANK, X, O}
