interface Renderer {
    /**
     * presents the board as chosen: renderer or none
     * @param board of the game
     */
    public void renderBoard(Board board);
}
